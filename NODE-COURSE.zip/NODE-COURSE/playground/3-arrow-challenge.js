// goal: create method to get incomplete tasks
// 1. define getTasksToDo method
// 2.Use filter to to return just the incomplete tasks (arrow function)
// 3.Test your work by running the  script

const task = {
    tasks: [{
        text: 'Grocery shopping',
        completed: true
    },{
        text: 'Clean yard',
        completed: false
    },{
        text: 'Film course',
        completed: false
    }],
    getTasksToDo(){
        return this.tasks.filter((task) => task.completed === false)
    }
}

console.log(task.getTasksToDo()) 